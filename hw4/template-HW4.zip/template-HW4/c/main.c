#include <stdio.h>

int main(int argc, char **argv){
	//argv[1] : name of data graph file
	//argv[2] : name of query graph file
	//argv[3] : the number of query in query graph
	
	//read data graph file
	//read query graph file
	//find the dag for each query graph
	return 0;
}
