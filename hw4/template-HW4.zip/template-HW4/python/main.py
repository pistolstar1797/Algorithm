import sys

if __name__=="__main__":
    pass
    #sys.argv[1] : name of data graph file
    #sys.argv[2] : name of query graph file
    #sys.argv[3] : the number of query in query graph file

    #read the data graph file
    #read the query graph file
    #find the dag for each query file
