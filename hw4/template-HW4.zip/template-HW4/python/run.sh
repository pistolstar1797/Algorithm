python main.py human human_40n 100 > human_40n.dag
