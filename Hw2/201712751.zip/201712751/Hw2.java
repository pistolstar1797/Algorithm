class Node {
    public static final int BLACK = 0, RED = 1;
    int data, color, Lnum, Rnum;
    Node parent, left, right;

    Node(int data) {
        this.data = data;
        this.color = BLACK;
        this.Lnum = 0;
        this.Rnum = 0;
        this.parent = null;
        this.left = null;
        this.right = null;
    }
}

public class Hw2 {
    static Node NIL = new Node(0);
    static Node root = NIL;

    public static void init() {
        root = NIL;
        root.parent = NIL;
        root.left = NIL;
        root.right = NIL;
    }

    public static String print() {
        return root.toString();
    }

    private static boolean isNIL(Node node) {
        return node == NIL;
    }

    private static void rotateL(Node x) {
        rotateLAS(x);

        Node y;
        y = x.right;
        x.right = y.left;

        if (!isNIL(y.left))
            y.left.parent = x;
        y.parent = x.parent;

        if (isNIL(x.parent))
            root = y;

        else if (x.parent.left == x)
            x.parent.left = y;

        else
            x.parent.right = y;

        y.left = x;
        x.parent = y;
    }

    private static void rotateLAS(Node x) {
        if (isNIL(x.left) && isNIL(x.right.left)) {
            x.Lnum = 0;
            x.Rnum = 0;
            x.right.Lnum = 1;
        }

        else if (isNIL(x.left) && !isNIL(x.right.left)) {
            x.Lnum = 0;
            x.Rnum = 1 + x.right.left.Lnum + x.right.left.Rnum;
            x.right.Lnum = 2 + x.right.left.Lnum + x.right.left.Rnum;
        }

        else if (!isNIL(x.left) && isNIL(x.right.left)) {
            x.Rnum = 0;
            x.right.Lnum = 2 + x.left.Lnum + x.left.Rnum;

        } else {
            x.Rnum = 1 + x.right.left.Lnum + x.right.left.Rnum;
            x.right.Lnum = 3 + x.left.Lnum + x.left.Rnum + x.right.left.Lnum + x.right.left.Rnum;
        }

    }

    private static void rotateR(Node y) {
        rotateRAS(y);

        Node x = y.left;
        y.left = x.right;

        if (!isNIL(x.right))
            x.right.parent = y;
        x.parent = y.parent;

        if (isNIL(y.parent))
            root = x;
        else if (y.parent.right == y)
            y.parent.right = x;
        else
            y.parent.left = x;

        x.right = y;
        y.parent = x;

    }

    private static void rotateRAS(Node y) {
        if (isNIL(y.right) && isNIL(y.left.right)) {
            y.Rnum = 0;
            y.Lnum = 0;
            y.left.Rnum = 1;
        }

        else if (isNIL(y.right) && !isNIL(y.left.right)) {
            y.Rnum = 0;
            y.Lnum = 1 + y.left.right.Rnum + y.left.right.Lnum;
            y.left.Rnum = 2 + y.left.right.Rnum + y.left.right.Lnum;
        }

        else if (!isNIL(y.right) && isNIL(y.left.right)) {
            y.Lnum = 0;
            y.left.Rnum = 2 + y.right.Rnum + y.right.Lnum;

        }

        else {
            y.Lnum = 1 + y.left.right.Rnum + y.left.right.Lnum;
            y.left.Rnum = 3 + y.right.Rnum + y.right.Lnum + y.left.right.Rnum + y.left.right.Lnum;
        }
    }

    public static int osInsert(int x) {
        if (search(x) != null) {
            return 0;
        } else {
            insert(new Node(x));
            return x;
        }
    }

    private static void insert(Node z) {
        Node y = NIL;
        Node x = root;

        while (!isNIL(x)) {
            y = x;

            if (z.data < x.data) {
                x.Lnum++;
                x = x.left;
            }

            else {
                x.Rnum++;
                x = x.right;
            }
        }

        z.parent = y;

        if (isNIL(y))
            root = z;
        else if (z.data < y.data)
            y.left = z;
        else
            y.right = z;

        z.left = NIL;
        z.right = NIL;
        z.color = Node.RED;

        insertAS(z);
    }

    private static void insertAS(Node z) {
        Node y = NIL;

        while (z.parent.color == Node.RED) {
            if (z.parent == z.parent.parent.left) {
                y = z.parent.parent.right;

                if (y.color == Node.RED) {
                    z.parent.color = Node.BLACK;
                    y.color = Node.BLACK;
                    z.parent.parent.color = Node.RED;
                    z = z.parent.parent;
                }

                else if (z == z.parent.right) {
                    z = z.parent;
                    rotateL(z);
                }

                else {
                    z.parent.color = Node.BLACK;
                    z.parent.parent.color = Node.RED;
                    rotateR(z.parent.parent);
                }
            }

            else {
                y = z.parent.parent.left;

                if (y.color == Node.RED) {
                    z.parent.color = Node.BLACK;
                    y.color = Node.BLACK;
                    z.parent.parent.color = Node.RED;
                    z = z.parent.parent;
                }

                else if (z == z.parent.left) {
                    z = z.parent;
                    rotateR(z);
                }

                else {
                    z.parent.color = Node.BLACK;
                    z.parent.parent.color = Node.RED;
                    rotateL(z.parent.parent);
                }
            }
        }
        root.color = Node.BLACK;
    }

    public static int osDelete(int x) {
        if (search(x) == null) {
            return 0;
        } else {
            remove(x);
            return x;
        }
    }

    public static Node minimum(Node node) {
        while (!isNIL(node.left))
            node = node.left;
        return node;
    }

    public static Node successor(Node x) {
        if (!isNIL(x.left))
            return minimum(x.right);

        Node y = x.parent;

        while (!isNIL(y) && x == y.right) {
            x = y;
            y = y.parent;
        }
        return y;
    }

    public static void remove(int v) {
        Node z = search(v);

        Node x = NIL;
        Node y = NIL;

        if (isNIL(z.left) || isNIL(z.right))
            y = z;

        else
            y = successor(z);

        if (!isNIL(y.left))
            x = y.left;
        else
            x = y.right;

        x.parent = y.parent;

        if (isNIL(y.parent))
            root = x;

        else if (!isNIL(y.parent.left) && y.parent.left == y)
            y.parent.left = x;

        else if (!isNIL(y.parent.right) && y.parent.right == y)
            y.parent.right = x;

        if (y != z) {
            z.data = y.data;
        }

        ASNodeData(x, y);

        if (y.color == Node.BLACK)
            removeAS(x);
    }

    private static void ASNodeData(Node x, Node y) {
        Node cur = NIL;
        Node trk = NIL;

        if (isNIL(x)) {
            cur = y.parent;
            trk = y;
        }

        else {
            cur = x.parent;
            trk = x;
        }

        while (!isNIL(cur)) {
            if (y.data != cur.data) {
                if (y.data > cur.data)
                    cur.Rnum--;

                if (y.data < cur.data)
                    cur.Lnum--;
            }

            else {
                if (isNIL(cur.left))
                    cur.Lnum--;
                else if (isNIL(cur.right))
                    cur.Rnum--;
                else if (trk == cur.right)
                    cur.Rnum--;
                else if (trk == cur.left)
                    cur.Lnum--;
            }

            trk = cur;
            cur = cur.parent;

        }

    }

    private static void removeAS(Node x) {
        Node w;

        while (x != root && x.color == Node.BLACK) {
            if (x == x.parent.left) {
                w = x.parent.right;

                if (w.color == Node.RED) {
                    w.color = Node.BLACK;
                    x.parent.color = Node.RED;
                    rotateL(x.parent);
                    w = x.parent.right;
                }

                if (w.left.color == Node.BLACK && w.right.color == Node.BLACK) {
                    w.color = Node.RED;
                    x = x.parent;
                }

                else {
                    if (w.right.color == Node.BLACK) {
                        w.left.color = Node.BLACK;
                        w.color = Node.RED;
                        rotateR(w);
                        w = x.parent.right;
                    }
                    w.color = x.parent.color;
                    x.parent.color = Node.BLACK;
                    w.right.color = Node.BLACK;
                    rotateL(x.parent);
                    x = root;
                }
            } else {
                w = x.parent.left;

                if (w.color == Node.RED) {
                    w.color = Node.BLACK;
                    x.parent.color = Node.RED;
                    rotateR(x.parent);
                    w = x.parent.left;
                }

                if (w.right.color == Node.BLACK && w.left.color == Node.BLACK) {
                    w.color = Node.RED;
                    x = x.parent;
                }

                else {
                    if (w.left.color == Node.BLACK) {
                        w.right.color = Node.BLACK;
                        w.color = Node.RED;
                        rotateL(w);
                        w = x.parent.left;
                    }

                    w.color = x.parent.color;
                    x.parent.color = Node.BLACK;
                    w.left.color = Node.BLACK;
                    rotateR(x.parent);
                    x = root;
                }
            }
        }

        x.color = Node.BLACK;
    }

    public static Node search(int data) {
        Node cur = root;

        while (!isNIL(cur)) {
            if (cur.data == data)
                return cur;

            else if (cur.data < data)
                cur = cur.right;

            else
                cur = cur.left;
        }

        return null;
    }

    public static int osSelect(int i) {
        if (root.Lnum + root.Rnum + 1 < i)
            return 0;
        else
            return select(root, i);
    }

    public static int select(Node x, int i) {
        int r = x.Lnum + 1;

        if (i == r) {
            return x.data;
        } else if (i < r) {
            return select(x.left, i);
        } else {
            return select(x.right, i - r);
        }
    }

    public static int osRank(int x) {
        if (search(x) == null) {
            return 0;
        } else {
            return rank(root, x);
        }
    }

    public static int rank(Node node, int data) {
        if (isNIL(node))
            return 1;
        else if (data <= node.data)
            return rank(node.left, data);
        else
            return 1 + node.Lnum + rank(node.right, data);
    }

    public static boolean check(int[] opt_seq, int[] in_seq, int[] out_seq, int n) {
        int[] a = new int[10000];

        for (int i = 0; i < n; i++) {
            if (opt_seq[i] == 0) {
                if (a[in_seq[i]] == 0) {
                    if (out_seq[i] != in_seq[i]) {
                        return false;
                    } else {
                        a[in_seq[i]] = 1;
                    }
                } else if (a[in_seq[i]] == 1) {
                    if (out_seq[i] != 0) {
                        return false;
                    }
                }
            } else if (opt_seq[i] == 1) {
                if (a[in_seq[i]] == 1) {
                    if (out_seq[i] != in_seq[i]) {
                        return false;
                    } else {
                        a[in_seq[i]] = 0;
                    }
                } else if (a[in_seq[i]] == 0) {
                    if (out_seq[i] != 0) {
                        return false;
                    }
                }
            } else if (opt_seq[i] == 2) {
                int cnt = 0;
                int j = 1;

                while (cnt < in_seq[i] && j < 10000) {
                    cnt += a[j];
                    j++;
                }

                if ((j - 1) != out_seq[i] && j < 10000) {
                    return false;
                }
            } else if (opt_seq[i] == 3) {
                int cnt = 0;

                for (int j = 1; j <= in_seq[i]; j++) {
                    cnt += a[j];
                }

                if (cnt != out_seq[i] && a[in_seq[i]] == 1) {
                    return false;
                }
            }
        }

        return true;
    }
}
